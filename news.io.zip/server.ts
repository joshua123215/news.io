import express from "express";
import { createServer as createViteServer } from "vite";
import Parser from "rss-parser";
import path from "path";

type FeedCategory = {
  id: string;
  name: string;
  url: string;
  isPremium?: boolean;
};

const CATEGORIES: FeedCategory[] = [
  { id: "top", name: "Top Stories", url: "http://feeds.bbci.co.uk/news/rss.xml" },
  { id: "world", name: "World", url: "http://feeds.bbci.co.uk/news/world/rss.xml" },
  { id: "business", name: "Business", url: "http://feeds.bbci.co.uk/news/business/rss.xml" },
  { id: "technology", name: "Technology", url: "http://feeds.bbci.co.uk/news/technology/rss.xml" },
  { id: "science", name: "Science", url: "http://feeds.bbci.co.uk/news/science_and_environment/rss.xml" },
  { id: "health", name: "Health", url: "http://feeds.bbci.co.uk/news/health/rss.xml" },
  { id: "entertainment", name: "Entertainment", url: "http://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml" },
  { id: "sports", name: "Sports", url: "http://feeds.bbci.co.uk/sport/rss.xml" },
  { id: "vip_crypto", name: "VIP Crypto", url: "https://www.coindesk.com/arc/outboundfeeds/rss/", isPremium: true },
];

const parser = new Parser({
  customFields: {
    item: [
      ['media:thumbnail', 'mediaThumbnail'],
    ],
  }
});

let cache: Record<string, { data: any, timestamp: number }> = {};
const CACHE_DURATION_MS = 5 * 60 * 1000; // 5 minutes

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.get("/api/categories", (req, res) => {
    res.json(CATEGORIES.map(c => ({ id: c.id, name: c.name, isPremium: c.isPremium })));
  });

  app.get("/api/news", async (req, res) => {
    try {
      const selectedCategories = (req.query.categories as string)?.split(",") || ["top"];
      const feedsToFetch = CATEGORIES.filter(c => selectedCategories.includes(c.id));
      
      let allItems: any[] = [];

      for (const category of feedsToFetch) {
        const cacheKey = category.id;
        let feedData;

        // Check if fresh cache exists
        if (cache[cacheKey] && (Date.now() - cache[cacheKey].timestamp) < CACHE_DURATION_MS) {
          feedData = cache[cacheKey].data;
        } else {
          try {
            feedData = await parser.parseURL(category.url);
            cache[cacheKey] = { data: feedData, timestamp: Date.now() };
          } catch (error) {
            console.error(`Failed to fetch ${category.id}:`, error);
            continue; // Skip this feed on error
          }
        }

        if (feedData && feedData.items) {
          const itemsWithCategory = feedData.items.map(item => {
            // BBC uses strings for media:thumbnail. We need to extract the url safely
            let imageUrl = null;
            if (item.mediaThumbnail && typeof item.mediaThumbnail === "object" && item.mediaThumbnail.$) {
               imageUrl = item.mediaThumbnail.$.url;
            } else if (item.enclosure && item.enclosure.url && item.enclosure.type && item.enclosure.type.startsWith('image/')) {
               imageUrl = item.enclosure.url;
            }

            return {
              id: item.guid || item.link || Math.random().toString(),
              title: item.title,
              link: item.link,
              pubDate: item.pubDate,
              contentSnippet: item.contentSnippet || item.content,
              categoryId: category.id,
              categoryName: category.name,
              imageUrl: imageUrl
            };
          });
          allItems = allItems.concat(itemsWithCategory);
        }
      }

      // Sort by publication date (newest first)
      allItems.sort((a, b) => {
        const dateA = new Date(a.pubDate || 0).getTime();
        const dateB = new Date(b.pubDate || 0).getTime();
        return dateB - dateA;
      });

      res.json({ items: allItems.slice(0, 100) });

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to aggregate news feeds" });
    }
  });

  app.post("/api/paystack/initialize", express.json(), async (req, res) => {
    try {
      const secretKey = process.env.PAYSTACK_SECRET_KEY || "sk_live_aa98fdb5bc3d8eaa794bf2cb77d8d6a81aa716f7";
      
      const response = await fetch("https://api.paystack.co/transaction/initialize", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: req.body.email || "user@example.com",
          amount: 6000, // 6000 pesewas = 60.00 GHS
          currency: "GHS",
          // Redirect back to the app with a success parameter
          callback_url: `${req.headers.origin || "http://localhost:3000"}?payment=success`,
        }),
      });

      const data = await response.json();
      if (data.status) {
        res.json({ authorization_url: data.data.authorization_url });
      } else {
        res.status(400).json({ error: data.message });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to initialize payment" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // ES Modules in Node don't have __dirname, need to derive path from cwd
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
