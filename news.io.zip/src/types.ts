export interface Category {
  id: string;
  name: string;
  isPremium?: boolean;
}

export interface NewsItem {
  id: string;
  title: string;
  link: string;
  pubDate: string;
  contentSnippet: string;
  categoryId: string;
  categoryName: string;
  imageUrl: string | null;
}
