import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, Zap, Shield, Crown, Bell, CreditCard, ChevronLeft } from 'lucide-react';

interface SubscribeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscribe: () => void;
}

export function SubscribeModal({ isOpen, onClose, onSubscribe }: SubscribeModalProps) {
  const [step, setStep] = useState<'benefits' | 'payment'>('benefits');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleClose = () => {
    onClose();
    setTimeout(() => setStep('benefits'), 300); // reset state after close animation
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 bg-[#1A1A1A]/60 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md bg-[#FAF9F6] rounded-2xl shadow-2xl z-50 overflow-hidden border border-[#EAE8E4]"
          >
            <div className="p-8">
              {step === 'payment' && (
                 <button 
                  onClick={() => setStep('benefits')}
                  className="absolute top-4 left-4 p-2 text-[#8C8A85] hover:text-[#1A1A1A] transition-colors rounded-full hover:bg-black/5"
                 >
                  <ChevronLeft className="w-5 h-5" />
                 </button>
              )}
              <button 
                onClick={handleClose}
                className="absolute top-4 right-4 p-2 text-[#8C8A85] hover:text-[#1A1A1A] transition-colors rounded-full hover:bg-black/5"
              >
                <X className="w-5 h-5" />
              </button>
              
              <AnimatePresence mode="wait">
                {step === 'benefits' ? (
                  <motion.div 
                    key="benefits"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="flex justify-center mb-6 mt-4">
                      <div className="w-16 h-16 bg-[#1A1A1A] rounded-full flex items-center justify-center">
                        <Crown className="w-8 h-8 text-[#FAF9F6]" />
                      </div>
                    </div>

                    <div className="text-center mb-8">
                      <h2 className="text-3xl font-serif font-black text-[#1A1A1A] mb-2 tracking-tight">Premium Membership</h2>
                      <p className="text-sm font-medium text-[#8C8A85]">Elevate your news experience.</p>
                    </div>

                    <div className="space-y-4 mb-8">
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-[#1A1A1A]/5 flex items-center justify-center shrink-0">
                          <Shield className="w-4 h-4 text-[#1A1A1A]" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-[#1A1A1A]">Ad-Free Version</h4>
                          <p className="text-xs text-[#8C8A85] font-medium">Read without interruptions.</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-[#1A1A1A]/5 flex items-center justify-center shrink-0">
                          <CheckCircle className="w-4 h-4 text-[#1A1A1A]" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-[#1A1A1A]">Exclusive Stories</h4>
                          <p className="text-xs text-[#8C8A85] font-medium">Deep-dives & investigative pieces.</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-[#1A1A1A]/5 flex items-center justify-center shrink-0">
                          <Bell className="w-4 h-4 text-[#1A1A1A]" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-[#1A1A1A]">Faster News Alerts</h4>
                          <p className="text-xs text-[#8C8A85] font-medium">Get notifications on the latest news.</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-[#1A1A1A]/5 flex items-center justify-center shrink-0">
                          <Zap className="w-4 h-4 text-[#1A1A1A]" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-[#1A1A1A]">VIP Crypto</h4>
                          <p className="text-xs text-[#8C8A85] font-medium">Access to the VIP Crypto markets feed.</p>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setStep('payment')}
                      className="w-full py-4 px-6 bg-[#1A1A1A] hover:bg-[#33322E] text-white rounded-xl font-bold tracking-wide transition-colors flex justify-between items-center focus:outline-none focus:ring-4 focus:ring-black/10"
                    >
                      <span>Continue to Payment</span>
                      <span>GHS 60.00/mo</span>
                    </button>
                    <p className="text-center mt-4 text-[10px] text-[#8C8A85] uppercase tracking-widest font-bold">Cancel anytime</p>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="payment"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="text-center mb-8 mt-4">
                      <h2 className="text-2xl font-serif font-black text-[#1A1A1A] mb-2 tracking-tight">Complete Payment</h2>
                      <p className="text-sm font-medium text-[#8C8A85]">Choose your preferred payment method.</p>
                    </div>

                    <div className="space-y-4 mb-8">
                       <button 
                         onClick={async () => {
                           setIsSubmitting(true);
                           try {
                             const res = await fetch('/api/paystack/initialize', { method: 'POST' });
                             const data = await res.json();
                             if (data.authorization_url) {
                               window.location.href = data.authorization_url;
                             } else {
                               alert("Failed to initialize payment: " + data.error);
                             }
                           } catch (err) {
                             alert("Error connecting to payment provider");
                           } finally {
                             setIsSubmitting(false);
                           }
                         }}
                         disabled={isSubmitting}
                         className="w-full flex items-center gap-4 p-4 border border-[#EAE8E4] rounded-xl hover:bg-black/5 hover:border-[#D0CECB] transition-all group disabled:opacity-50"
                       >
                         <div className="w-10 h-10 rounded-full bg-white border border-[#EAE8E4] flex items-center justify-center shrink-0 drop-shadow-sm group-hover:scale-105 transition-transform">
                           <CreditCard className="w-5 h-5 text-[#1A1A1A]" />
                         </div>
                         <div className="text-left flex-1">
                           <h4 className="text-sm font-bold text-[#1A1A1A]">Paystack / Card</h4>
                           <p className="text-xs text-[#8C8A85] font-medium">Pay securely with your card</p>
                         </div>
                       </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
