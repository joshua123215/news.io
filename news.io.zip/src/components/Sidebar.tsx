import React from 'react';
import { Category } from '../types';
import { Check, Lock, Crown } from 'lucide-react';
import { motion } from 'motion/react';

interface SidebarProps {
  categories: Category[];
  selectedIds: string[];
  onToggle: (id: string) => void;
  isOpen?: boolean;
  isSubscribed?: boolean;
  onSubscribeClick?: () => void;
}

export function Sidebar({ categories, selectedIds, onToggle, isOpen = true, isSubscribed = false, onSubscribeClick }: SidebarProps) {
  return (
    <aside className={`w-full lg:w-64 border-r border-[#EAE8E4] bg-[#F7F5F0] p-6 flex-col gap-6 h-full shrink-0 ${isOpen ? 'flex' : 'hidden lg:flex'}`}>
      <div className="sticky top-0 h-full overflow-y-auto custom-scrollbar flex flex-col">
        <div className="mb-10 mt-2">
          <div className="text-3xl font-serif font-black tracking-tight text-[#1A1A1A] mb-1">News.io</div>
          <div className="text-[9px] uppercase tracking-[0.25em] font-bold text-[#8C8A85]">Premium Edition</div>
        </div>

        <div className="flex-1">
          <h3 className="text-[10px] uppercase tracking-widest font-bold text-[#8C8A85] mb-4">Channels</h3>
          <ul className="space-y-1.5">
            {categories.map((category) => {
              const checked = selectedIds.includes(category.id);
              const isLocked = category.isPremium && !isSubscribed;

              return (
                <li key={category.id}>
                  <button
                    onClick={() => {
                      if (isLocked) {
                        onSubscribeClick?.();
                      } else {
                        onToggle(category.id);
                      }
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm transition-all focus:outline-none ${
                        checked 
                          ? 'bg-[#1A1A1A] text-white shadow-sm' 
                          : 'text-[#5C5A55] hover:bg-black/5'
                      }`}
                  >
                    <span className="font-medium tracking-wide flex items-center gap-2">
                      {category.name}
                      {isLocked && <Lock className="w-3 h-3 text-[#B0AD9E]" />}
                    </span>
                    {checked && (
                      <span className="text-[10px] bg-white/20 text-white px-1.5 py-0.5 rounded flex items-center justify-center">✓</span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
        
        {!isSubscribed && (
          <div className="mt-8 bg-[#1A1A1A] text-[#FAF9F6] p-5 rounded-xl border border-[#33322E] shrink-0">
            <h4 className="flex items-center gap-2 font-bold text-sm mb-2"><Crown className="w-4 h-4 text-amber-200" /> Upgrade to Pro</h4>
            <p className="text-xs text-[#8C8A85] mb-4 font-medium leading-relaxed">Ad-free reading, VIP Crypto feed, early alerts & exclusive stories.</p>
            <button 
              onClick={onSubscribeClick}
              className="w-full py-2 bg-[#FAF9F6] text-[#1A1A1A] text-xs font-bold rounded-lg hover:bg-white transition-colors"
            >
              Get Premium Access
            </button>
          </div>
        )}
      </div>
    </aside>
  );
}
