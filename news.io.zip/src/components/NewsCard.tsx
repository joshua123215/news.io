import React from 'react';
import { NewsItem } from '../types';
import { motion } from 'motion/react';

interface NewsCardProps {
  item: NewsItem;
  featured?: boolean;
}

export function NewsCard({ item, featured = false }: NewsCardProps) {
  const publishedAt = new Date(item.pubDate);
  const timeAgo = getRelativeTime(publishedAt);

  if (featured) {
    return (
      <motion.a
        href={item.link}
        target="_blank"
        rel="noopener noreferrer"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="group relative block w-full rounded-2xl overflow-hidden bg-[#1A1A1A] h-[280px] md:h-[400px] shadow-sm transform transition-transform duration-500 hover:-translate-y-1"
      >
        {item.imageUrl && (
          <div className="absolute inset-0">
            <img 
              src={item.imageUrl} 
              alt={item.title} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A] via-[#1A1A1A]/50 to-transparent opacity-90" />
            <div className="absolute inset-0 bg-[#A0988A] mix-blend-multiply opacity-20"></div>
          </div>
        )}
        <div className="absolute bottom-0 p-6 md:p-10 text-[#FAF9F6] w-full">
          <span className="px-2.5 py-1 bg-white/10 backdrop-blur-md text-white rounded text-[10px] font-bold uppercase tracking-widest mb-4 inline-block border border-white/20">
            {item.categoryName}
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-black leading-[1.1] mb-3 group-hover:text-white/80 transition-colors">
            {item.title}
          </h2>
          <p className="text-sm md:text-base text-[#D4D2CD] line-clamp-2 md:line-clamp-3 font-medium max-w-3xl">
            {item.contentSnippet}
          </p>
        </div>
      </motion.a>
    );
  }

  return (
    <motion.a
      href={item.link}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="group flex flex-col bg-white border border-[#EAE8E4] rounded-2xl p-5 hover:shadow-lg transition-all duration-300 h-full hover:border-[#D0CECB] hover:-translate-y-1"
    >
      {item.imageUrl ? (
        <div className="w-full h-32 md:h-40 shrink-0 relative overflow-hidden rounded-xl mb-4 bg-[#F7F5F0]">
          <img 
            src={item.imageUrl} 
            alt={item.title} 
            className="w-full h-full object-cover absolute inset-0 group-hover:scale-105 transition-transform duration-500" 
            loading="lazy" 
            referrerPolicy="no-referrer"
          />
        </div>
      ) : (
        <div className="w-full h-32 md:h-40 shrink-0 rounded-xl mb-4 bg-[#F7F5F0] flex items-center justify-center text-[#8C8A85] border border-[#EAE8E4]">
          <span className="text-[10px] font-bold uppercase tracking-widest">No Image</span>
        </div>
      )}
      <div className="flex flex-col font-sans flex-1">
        <span className="text-[10px] text-[#8C8A85] font-bold mb-2 uppercase tracking-widest">
          {item.categoryName} • {timeAgo}
        </span>
        <h3 className="text-base md:text-lg font-serif font-bold mb-2 leading-tight text-[#1A1A1A] group-hover:text-[#5C5A55] transition-colors line-clamp-3">
          {item.title}
        </h3>
        <p className="text-[13px] text-[#5C5A55] line-clamp-3 leading-relaxed mb-1 mt-auto">
          {item.contentSnippet}
        </p>
      </div>
    </motion.a>
  );
}

function getRelativeTime(date: Date) {
  const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
  const diffInDays = (date.getTime() - Date.now()) / (1000 * 60 * 60 * 24);
  const diffInHours = (date.getTime() - Date.now()) / (1000 * 60 * 60);
  const diffInMinutes = (date.getTime() - Date.now()) / (1000 * 60);

  if (Math.abs(diffInDays) >= 1) {
    return rtf.format(Math.round(diffInDays), 'day');
  }
  if (Math.abs(diffInHours) >= 1) {
    return rtf.format(Math.round(diffInHours), 'hour');
  }
  if (Math.abs(diffInMinutes) >= 1) {
    return rtf.format(Math.round(diffInMinutes), 'minute');
  }
  return 'just now';
}
