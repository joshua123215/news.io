import React, { useEffect, useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { NewsCard } from './components/NewsCard';
import { SubscribeModal } from './components/SubscribeModal';
import { Category, NewsItem } from './types';
import { Loader2, Menu, Bell, BellRing, Settings, Crown, LogOut, User as UserIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from './hooks/useAuth';

export default function App() {
  const { user, loading: authLoading, signInWithGoogle, logout } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);

  const [selectedCategories, setSelectedCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('newsflow_prefs');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return ['top']; 
  });
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(() => {
    return localStorage.getItem('newsflow_subscribed') === 'true';
  });
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    return localStorage.getItem('newsflow_notifications') === 'true';
  });
  const [isSubscribeModalOpen, setIsSubscribeModalOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  useEffect(() => {
    // Handle Paystack payment success callback
    const params = new URLSearchParams(window.location.search);
    if (params.get('payment') === 'success') {
      setIsSubscribed(true);
      localStorage.setItem('newsflow_subscribed', 'true');
      alert("Payment successful! You are now a Premium member.");
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    fetch('/api/categories')
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error("Failed to load categories", err));
  }, []);

  useEffect(() => {
    localStorage.setItem('newsflow_prefs', JSON.stringify(selectedCategories));

    if (selectedCategories.length === 0) {
      setNewsItems([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    const qs = selectedCategories.join(',');
    fetch(`/api/news?categories=${qs}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch news');
        return res.json();
      })
      .then(data => {
        setNewsItems(data.items || []);
      })
      .catch(err => {
        setError(err instanceof Error ? err.message : 'Unknown error');
      })
      .finally(() => {
        setLoading(false);
      });
  }, [selectedCategories]);

  const handleToggleCategory = (id: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(id)) {
        return prev.filter(c => c !== id);
      }
      return [...prev, id];
    });
  };

  const handleSubscribe = () => {
    setIsSubscribed(true);
    localStorage.setItem('newsflow_subscribed', 'true');
    alert("You have successfully subscribed to Premium!");
  };

  const handleToggleNotifications = async () => {
    if (!isSubscribed) {
      setIsSubscribeModalOpen(true);
      return;
    }
    
    if (!notificationsEnabled) {
      if (!("Notification" in window)) {
        alert("This browser does not support desktop notifications.");
        return;
      }
      
      let permission = Notification.permission;
      if (permission === 'default') {
         permission = await Notification.requestPermission();
      }
      
      if (permission === "granted") {
        setNotificationsEnabled(true);
        localStorage.setItem('newsflow_notifications', 'true');
        new Notification("News.io", { body: "Push notifications for breaking news are now enabled!" });
      } else {
        alert("Notification permission denied. Please enable them in your browser settings.");
      }
    } else {
      setNotificationsEnabled(false);
      localStorage.setItem('newsflow_notifications', 'false');
    }
  };

  useEffect(() => {
    if (!notificationsEnabled || !isSubscribed) return;

    let initialId = newsItems.length > 0 ? newsItems[0].id : null;
    let storedId = localStorage.getItem('newsflow_last_article_id');
    if (!storedId && initialId) {
      localStorage.setItem('newsflow_last_article_id', initialId);
    }

    const intervalId = setInterval(() => {
      fetch('/api/news?categories=top')
        .then(res => res.json())
        .then(data => {
          if (data.items && data.items.length > 0) {
            const latestArticle = data.items[0];
            const currentStoredId = localStorage.getItem('newsflow_last_article_id');
            if (currentStoredId && latestArticle.id !== currentStoredId) {
              localStorage.setItem('newsflow_last_article_id', latestArticle.id);
              if ("Notification" in window && Notification.permission === "granted") {
                new Notification("Breaking News", {
                  body: latestArticle.title,
                  icon: latestArticle.imageUrl || undefined
                });
              }
            } else if (!currentStoredId) {
              localStorage.setItem('newsflow_last_article_id', latestArticle.id);
            }
          }
        })
        .catch(err => console.error("Notification polling failed", err));
    }, 60000); 

    return () => clearInterval(intervalId);
  }, [notificationsEnabled, isSubscribed, newsItems]);

  const filteredNewsItems = newsItems.filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (item.contentSnippet && item.contentSnippet.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-[#FAF9F6] text-[#1A1A1A] font-sans overflow-hidden">
      {/* Mobile Header Menu */}
      <div className="lg:hidden flex items-center justify-between bg-[#F7F5F0] border-b border-[#EAE8E4] px-6 h-14 shrink-0 z-50">
        <div className="text-xl font-serif font-black tracking-tighter text-[#1A1A1A]">News.io</div>
        <div className="flex items-center gap-2">
          {!isSubscribed ? (
            <button 
              onClick={() => setIsSubscribeModalOpen(true)}
              className="px-3 py-1.5 rounded-full bg-[#1A1A1A] text-white text-[10px] font-bold"
            >
              UPGRADE
            </button>
          ) : (
            <button 
              onClick={() => {
                if(confirm('Reset premium status for testing?')) {
                  setIsSubscribed(false);
                  localStorage.removeItem('newsflow_subscribed');
                }
              }}
              className="px-2 py-1 rounded-full bg-amber-200 text-amber-900 border border-amber-300 flex items-center text-[10px] font-bold"
            >
              <Crown className="w-3 h-3 mr-1" /> PRO
            </button>
          )}

          {user ? (
            <div className="relative group cursor-pointer" onClick={logout} title="Click to Sign Out">
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || 'User'} className="w-7 h-7 rounded-full border border-[#D0CECB]" />
              ) : (
                 <div className="w-7 h-7 rounded-full bg-[#EAE8E4] border border-[#D0CECB] flex items-center justify-center text-[9px] font-bold text-[#5C5A55]">ME</div>
              )}
            </div>
          ) : (
             <button 
               onClick={signInWithGoogle}
               disabled={authLoading}
               className="flex items-center justify-center w-7 h-7 rounded-full border border-[#D0CECB] bg-white text-[#1A1A1A]"
             >
               <UserIcon className="w-3.5 h-3.5" />
             </button>
          )}

          <button 
            onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
            className="p-1 rounded-lg bg-black/5 hover:bg-black/10 text-[#1A1A1A] ml-1"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>

      <Sidebar 
        categories={categories} 
        selectedIds={selectedCategories} 
        onToggle={handleToggleCategory}
        isOpen={isMobileSidebarOpen}
        isSubscribed={isSubscribed}
        onSubscribeClick={() => setIsSubscribeModalOpen(true)}
      />

      <main className="flex-1 flex flex-col p-4 md:p-8 gap-8 overflow-y-auto custom-scrollbar bg-[#FAF9F6]">
        <div className="flex flex-col md:flex-row md:items-end justify-between shrink-0 mb-4 gap-4 border-b border-[#EAE8E4] pb-6">
          <div>
            <h2 className="text-4xl md:text-5xl font-serif font-black text-[#1A1A1A] mb-2 tracking-tight">Top Stories</h2>
             <p className="text-[11px] text-[#8C8A85] font-bold tracking-[0.2em] uppercase">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric'})}
            </p>
          </div>
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:flex-none">
              <span className="absolute left-3 top-2.5 text-[#8C8A85]">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
              </span>
              <input 
                type="text" 
                placeholder="Search global events..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-white rounded-full py-2 pl-9 pr-4 text-xs w-full md:w-64 focus:outline-none border border-[#EAE8E4] focus:border-[#C4C2BE] shadow-sm transition-all"
              />
            </div>
            
            <button
              onClick={handleToggleNotifications}
              className={`hidden md:flex p-2 rounded-full border transition-colors ${notificationsEnabled ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]' : 'bg-white text-[#8C8A85] border-[#EAE8E4] hover:bg-black/5 hover:text-[#1A1A1A]'}`}
              title={notificationsEnabled ? "Notifications On" : "Enable Notifications"}
            >
              {notificationsEnabled ? <BellRing className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
            </button>
            
            {isSubscribed ? (
              <div 
                className="hidden md:flex px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-200 to-amber-400 text-amber-900 border border-amber-300 items-center justify-center text-xs font-bold shadow-sm cursor-pointer hover:scale-105 transition-transform"
                onClick={() => {
                  if(confirm('Reset premium status for testing?')) {
                    setIsSubscribed(false);
                    localStorage.removeItem('newsflow_subscribed');
                  }
                }}
                title="Click to reset premium status"
              >
                <Crown className="w-3.5 h-3.5 mr-1" /> PRO
              </div>
            ) : (
              <button 
                onClick={() => setIsSubscribeModalOpen(true)}
                className="hidden md:flex px-4 py-1.5 rounded-full bg-[#1A1A1A] text-white items-center justify-center text-xs font-bold hover:bg-[#33322E] shadow-sm transition-colors"
              >
                Upgrade
              </button>
            )}

            {user ? (
              <div className="flex items-center gap-2 relative group hidden md:flex cursor-pointer">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || 'User'} className="w-8 h-8 rounded-full border border-[#D0CECB]" />
                ) : (
                   <div className="w-8 h-8 rounded-full bg-[#EAE8E4] border border-[#D0CECB] flex items-center justify-center text-[10px] font-bold text-[#5C5A55]">ME</div>
                )}
                <div onClick={logout} className="absolute top-9 right-0 bg-white border border-[#EAE8E4] rounded-lg shadow-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity z-50 p-1">
                  <button className="flex items-center gap-2 px-3 py-2 text-xs font-bold text-red-600 hover:bg-red-50 w-full rounded-md whitespace-nowrap">
                    <LogOut className="w-3.5 h-3.5" /> Sign Out
                  </button>
                </div>
              </div>
            ) : (
              <button 
                onClick={signInWithGoogle}
                disabled={authLoading}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D0CECB] bg-white text-[#1A1A1A] text-xs font-bold hover:bg-[#F7F5F0] transition-colors"
              >
                <UserIcon className="w-3.5 h-3.5" /> Sign In
              </button>
            )}
          </div>
        </div>

        {selectedCategories.length === 0 ? (
           <div className="flex flex-col items-center justify-center flex-1 text-center pb-20">
             <div className="text-4xl mb-4 opacity-20">🗞️</div>
             <h3 className="text-2xl font-serif font-bold text-[#1A1A1A] mb-2">Feed Empty</h3>
             <p className="text-sm text-[#8C8A85] max-w-sm font-medium">Select at least one channel from the sidebar to populate your feed.</p>
           </div>
        ) : error ? (
           <div className="flex justify-center p-6 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg shrink-0">
             <p className="font-medium">{error}</p>
           </div>
        ) : loading ? (
          <div className="flex flex-col items-center justify-center flex-1 pb-20">
            <Loader2 className="w-8 h-8 text-[#1A1A1A] animate-spin mb-4" />
            <span className="font-bold text-[#8C8A85] uppercase tracking-widest text-[10px]">Syncing Data...</span>
          </div>
        ) : filteredNewsItems.length === 0 ? (
          <div className="flex justify-center flex-1 items-center pb-20 text-[#8C8A85] font-bold uppercase tracking-widest text-[10px]">
            <p>{searchQuery ? 'No articles match your search.' : 'No new articles found.'}</p>
          </div>
        ) : (
          <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 auto-rows-max pb-8">
             <AnimatePresence>
               {filteredNewsItems.map((item, index) => {
                 // First item spans larger
                 const isFeatured = index === 0;
                 return (
                   <motion.div 
                     key={item.id}
                     layout
                     initial={{ opacity: 0, scale: 0.95 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.95 }}
                     transition={{ duration: 0.3 }}
                     className={isFeatured ? "col-span-1 sm:col-span-2 lg:col-span-3 xl:col-span-2" : "col-span-1 h-full"}
                   >
                     <NewsCard item={item} featured={isFeatured} />
                   </motion.div>
                 );
               })}
             </AnimatePresence>
          </motion.div>
        )}
      </main>

      <SubscribeModal 
        isOpen={isSubscribeModalOpen} 
        onClose={() => setIsSubscribeModalOpen(false)}
        onSubscribe={handleSubscribe} 
      />
    </div>
  );
}
